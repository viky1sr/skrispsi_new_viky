<?php

namespace App\Models\HomeCare;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InfoPembayaranHomeCare extends Model
{
    use HasFactory;
}
