<?php

namespace App\Models\BabySpa;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MasterBabySpa extends Model
{
    use HasFactory;
}
